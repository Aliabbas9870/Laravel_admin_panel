<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Developer extends Model
{
    //



    protected $table= "developers";

    // public $timestamps = false;
    protected $primaryKey= "id";

    protected $fillable = [
        'name', 'title', 'description', 'photo',
        'icon_1_text', 'icon_2_text', 'icon_3_text',
        'copyright_text', 'sort_order'
    ];
}
