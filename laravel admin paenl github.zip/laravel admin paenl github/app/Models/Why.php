<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Why extends Model
{
    protected $table = 'why';
    public $timestamps = false;
    protected $primaryKey = 'id'; // Explicitly set primary key

}
