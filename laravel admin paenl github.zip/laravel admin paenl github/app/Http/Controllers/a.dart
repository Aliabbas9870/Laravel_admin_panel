void main(){
    var a=6;
    var b=4;
    print("a= $a and b= $b");

    a=a+b;
    b=a-b;
    a=a-b;

    print("a= $a and b= $b  after");
}
