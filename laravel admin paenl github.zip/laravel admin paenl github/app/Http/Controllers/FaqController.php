<?php

namespace App\Http\Controllers;
use App\Models\Faq;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    public function index(){
        $faq = Faq::all();

        return view('faq',compact("faq"));
    }


    public function show(){
        $faq = Faq::all();

        return view('faqView',compact("faq"));
    }

    public function edit($id)
    {
        $faq = FAQ::findOrFail($id);
        return view('faqEdit', compact('faq'));
    }

    // Update FAQ
    public function update(Request $request, $id)
    {
        $request->validate([
            'question' => 'required|string',
            'answer' => 'required|string',
            'page_id' => 'nullable|integer',
            'developer_id' => 'nullable|integer',
            'status' => 'required|in:1,0',
        ]);

        $faq = FAQ::findOrFail($id);
        $faq->update([
            'question' => $request->question,
            'answer' => $request->answer,
            'page_id' => $request->page_id,
            'developer_id' => $request->developer_id,
            'status' => $request->status,
        ]);

        return redirect()->route('faq.edit', $id)->with('success', 'FAQ updated successfully!');
    }

    public function create()
    {
        return view('faq');
    }

    // Store FAQ
    public function store(Request $request)
    {
        $request->validate([

            'question' => 'required|string',
            'answer' => 'required|string',
            'page_id' => 'nullable|integer',
            'developer_id' => 'nullable|integer',
            'status' => 'required|boolean',
        ]);

        Faq::create($request->all());

        return redirect()->back()->with('success', 'FAQ added successfully!');
    }

    public function destroy(string $id)
    {
        $page = Faq::findOrFail($id);

        // Delete the page
        $page->delete();

        // Redirect with success message
        return redirect()->route("home")->with('success', 'FAQs deleted successfully.');

    }
    // Show all FAQs
    /**
     * Store a newly created resource in storage.
     */


    /**
     * Show the form for editing the specified resource.
     */


    /**
     * Update the specified resource in storage.
     */

    /**
     * Remove the specified resource from storage.
     */

}
