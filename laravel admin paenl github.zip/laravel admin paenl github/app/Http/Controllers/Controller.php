<?php

namespace App\Http\Controllers;

abstract class Controller
{



    //

    // composer create-project "laravel/laravel:^10.0" admin
}
