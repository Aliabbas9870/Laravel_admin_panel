<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Developer;

class DeveloperController extends Controller
{
    //


    public function create()
    {
        return view('developer');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $photoPath = null;
        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('images/developers', 'public');
        }

        Developer::create([
            'name' => $request->name,
            'title' => $request->title,
            'description' => $request->description,
            'photo' => $photoPath,
            'icon_1_text' => $request->icon_1_text,
            'icon_2_text' => $request->icon_2_text,
            'icon_3_text' => $request->icon_3_text,
            'copyright_text' => $request->copyright_text,
            'sort_order' => $request->sort_order,
        ]);

        return redirect()->route('developer.show')->with('success', 'Developer added successfully.');
    }

    public function show()
    {
        $developers = Developer::all();
        // $developers = Developer::findOrFail($id);

        return view('developerView', compact('developers'));
    }

    public function edit($id)
    {
        $developer= Developer::findOrFail($id);
        return view('developerEdit', compact("developer"));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $developer = Developer::findOrFail($id);

        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('images/developers', 'public');
        } else {
            $photoPath = $developer->photo;
        }

        $developer->update([
            'name' => $request->name,
            'title' => $request->title,
            'description' => $request->description,
            'photo' => $photoPath,
            'icon_1_text' => $request->icon_1_text,
            'icon_2_text' => $request->icon_2_text,
            'icon_3_text' => $request->icon_3_text,
            'copyright_text' => $request->copyright_text,
            'sort_order' => $request->sort_order,
        ]);

        return redirect()->route('developer.show')->with('success', 'Developer updated successfully.');
    }

    public function destroy($id)
    {
        $developer = Developer::findOrFail($id);

        // if ($developer->photo) {
        //     \Storage::disk('public')->delete($developer->photo);
        // }

        $developer->delete();
        return redirect()->route('developer.show')->with('success', 'Developer deleted successfully.');
    }
}




